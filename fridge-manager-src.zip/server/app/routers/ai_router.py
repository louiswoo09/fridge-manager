import logging
import base64
import binascii
from typing import Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.services import ai_service, gemini_service

from fastapi import Depends
from app.auth import get_current_uid

router = APIRouter(prefix="/ai", tags=["AI"], dependencies=[Depends(get_current_uid)])
logger = logging.getLogger(__name__)


class VariantRequest(BaseModel):
    recipe_name: str = Field(..., min_length=1, max_length=200)
    recipe_ingredients: str = Field("", max_length=5000)
    manuals: list[str] = Field(default_factory=list, max_length=20)
    owned: list[str] = Field(default_factory=list, max_length=300)
    cart: list[str] = Field(default_factory=list, max_length=300)
    imminent: list[str] = Field(default_factory=list, max_length=300)
    mode: Literal["fridge", "shopping"] = "fridge"
    imminent_only: bool = False


class AnalysisRequest(BaseModel):
    ingredients: list[str] = Field(..., min_length=1, max_length=300)
    imminent: list[str] = Field(default_factory=list, max_length=300)


MAX_IMAGES = 5
MAX_IMAGE_BYTES = 5 * 1024 * 1024
MAX_TOTAL_BYTES = 15 * 1024 * 1024


class ImageInput(BaseModel):
    data: str = Field(..., min_length=100, max_length=7_000_000)
    mime_type: Literal["image/jpeg", "image/png", "image/webp"] = "image/jpeg"


class RecognizeRequest(BaseModel):
    images: list[ImageInput] = Field(..., min_length=1, max_length=MAX_IMAGES)

def _to_http_error(e: Exception, what: str) -> HTTPException:
    if isinstance(e, gemini_service.GeminiTimeout):
        logger.warning("%s: Gemini 응답 시간 초과", what)   # ← 이 줄만 추가
        return HTTPException(status_code=504, detail="AI 응답 시간이 초과되었습니다")
    if isinstance(e, gemini_service.GeminiError) and e.status in (429, 503):
        logger.warning("%s: Gemini 혼잡 (status=%s)", what, e.status)
        return HTTPException(status_code=503, detail="AI 요청이 많습니다")
    logger.exception("%s 실패", what)
    return HTTPException(status_code=502, detail="AI 응답 오류가 발생했습니다")

@router.post("/recipe-variant")
async def recipe_variant(req: VariantRequest):
    prompt = ai_service.build_variant_prompt(
        req.recipe_name, req.recipe_ingredients, req.manuals,
        req.owned, req.cart, req.imminent, req.mode, req.imminent_only,
    )
    try:
        text = await gemini_service.generate(prompt, json_mode=True, timeout=60)
    except Exception as e:
        raise _to_http_error(e, "레시피 변형")
    # 즐겨찾기 키가 이 텍스트로 만들어지므로 가공하지 않고 그대로 전달
    return {"text": text}


@router.post("/fridge-analysis")
async def fridge_analysis(req: AnalysisRequest):
    prompt = ai_service.build_analysis_prompt(req.ingredients, req.imminent)
    try:
        text = await gemini_service.generate(prompt, timeout=30)
    except Exception as e:
        raise _to_http_error(e, "냉장고 분석")
    if not text.strip():
        raise HTTPException(status_code=502, detail="AI 응답이 비어 있습니다")

    status, suggestion = ai_service.parse_analysis(text)
    return {"status": status, "suggestion": suggestion}

@router.post("/recognize-ingredients")
async def recognize_ingredients(req: RecognizeRequest):
    total = 0
    for img in req.images:
        try:
            raw = base64.b64decode(img.data, validate=True)
        except (binascii.Error, ValueError):
            raise HTTPException(status_code=400, detail="이미지 형식이 올바르지 않습니다")
        if len(raw) > MAX_IMAGE_BYTES:
            raise HTTPException(status_code=413, detail="이미지가 너무 큽니다")
        total += len(raw)
    if total > MAX_TOTAL_BYTES:
        raise HTTPException(status_code=413, detail="이미지 전체 용량이 너무 큽니다")

    try:
        text = await gemini_service.generate(
            ai_service.build_recognize_prompt(),
            json_mode=True,
            timeout=90,
            images=[(img.mime_type, img.data) for img in req.images],
            thinking_level="minimal",
        )
    except Exception as e:
        raise _to_http_error(e, "식재료 인식")

    return ai_service.parse_recognition(text)