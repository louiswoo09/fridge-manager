import 'package:flutter/material.dart';
import '../models/ingredient.dart';
import '../services/ingredient_recognition_service.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import '../widgets/expiration_date_field.dart';
import '../services/shelf_life_service.dart';

/// 사진·영수증 인식 결과를 확인하고 고친 뒤 등록할 재료 목록을 돌려주는 화면
/// 등록 버튼을 누르면 고친 재료 목록을 이전 화면으로 돌려줌
class RecognitionReviewScreen extends StatefulWidget {
  final RecognitionResult result;
  final List<XFile> photos;
  final List<Ingredient> existingItems;

  const RecognitionReviewScreen({
    super.key,
    required this.result,
    this.photos = const [],
    this.existingItems = const [],
  });

  @override
  State<RecognitionReviewScreen> createState() =>
      _RecognitionReviewScreenState();
}

/// 화면에서 수정 중인 재료 하나
class _Draft {
  bool selected = true;
  bool dateFromPhoto; // 사진에서 읽은 날짜인지
  bool dateEdited = false; // 사용자가 직접 바꿨는지
  final TextEditingController name;
  final TextEditingController quantity;
  String category;
  String unit;
  String storage;
  DateTime expirationDate;

  _Draft({
    required String name,
    required int quantity,
    required this.category,
    required this.unit,
    required this.storage,
    required this.expirationDate,
    this.dateFromPhoto = false,
  }) : name = TextEditingController(text: name),
       quantity = TextEditingController(text: '$quantity');

  void dispose() {
    name.dispose();
    quantity.dispose();
  }
}

class _RecognitionReviewScreenState extends State<RecognitionReviewScreen> {
  // 직접 추가 화면과 같은 선택지
  static const _categories = ['채소', '육류', '유제품', '과일', '해산물', '기타'];
  static const _units = ['개', 'g', 'ml', 'L', '팩'];
  static const _storages = ['냉장', '냉동', '실온'];

  late final List<_Draft> _drafts;

  /// 이름·카테고리·보관 방법으로 계산한 소비기한
  DateTime _estimateFor(String name, String category, String storage) =>
      ShelfLifeService()
          .estimate(name: name, category: category, storage: storage)
          .expirationDate;

  /// 사진 날짜도, 직접 고친 날짜도 아니면 자동 계산 값으로 다시 맞춤
  void _reestimate(_Draft d) {
    if (d.dateFromPhoto || d.dateEdited) return;
    d.expirationDate = _estimateFor(d.name.text, d.category, d.storage);
  }

  /// 서버가 이미 정리해서 보내지만, 혹시 모를 값은 기본값으로
  String _pick(String value, List<String> options, String fallback) =>
      options.contains(value) ? value : fallback;

  @override
  void initState() {
    super.initState();
    _drafts = widget.result.items.map((e) {
      final category = _pick(e.category, _categories, '기타');
      final storage = _pick(e.storage, _storages, '냉장');
      return _Draft(
        name: e.name,
        quantity: e.quantity,
        category: category,
        unit: _pick(e.unit, _units, '개'),
        storage: storage,
        // 사진에서 읽은 날짜가 없으면 자동 계산
        expirationDate:
            e.expirationDate ?? _estimateFor(e.name, category, storage),
        dateFromPhoto: e.expirationDate != null,
      );
    }).toList();
  }

  @override
  void dispose() {
    for (final d in _drafts) {
      d.dispose();
    }
    super.dispose();
  }

  int get _selectedCount => _drafts.where((d) => d.selected).length;
  bool get _allSelected =>
      _drafts.isNotEmpty && _drafts.every((d) => d.selected);

  void _toggleAll() {
    final value = !_allSelected;
    setState(() {
      for (final d in _drafts) {
        d.selected = value;
      }
    });
  }

  void _addEmpty() {
    setState(() {
      _drafts.add(
        _Draft(
          name: '',
          quantity: 1,
          category: '기타',
          unit: '개',
          storage: '냉장',
          expirationDate: _estimateFor('', '기타', '냉장'),
        ),
      );
    });
  }

  void _submit() {
    final selected = _drafts.where((d) => d.selected).toList();
    if (selected.isEmpty) return;

    if (selected.any((d) => d.name.text.trim().isEmpty)) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('이름이 비어 있는 재료가 있어요')));
      return;
    }

    final now = DateTime.now();
    final ingredients = selected.map((d) {
      final qty = int.tryParse(d.quantity.text.trim()) ?? 1;
      return Ingredient(
        id: '',
        name: d.name.text.trim(),
        category: d.category,
        quantity: qty < 1 ? 1 : qty,
        unit: d.unit,
        storage: d.storage,
        expirationDate: d.expirationDate,
        addedAt: now,
        isDeleted: false,
      );
    }).toList();

    Navigator.pop(context, ingredients);
  }

  bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  String _dDay(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final days = DateTime(
      date.year,
      date.month,
      date.day,
    ).difference(today).inDays;
    if (days < 0) return '${days.abs()}일 지남';
    if (days == 0) return 'D-Day';
    return 'D-$days';
  }

  /// 냉장고에 같은 이름 재료가 있으면 안내 한 줄
  Widget? _buildExistingHint(_Draft d) {
    final name = d.name.text.trim();
    if (name.isEmpty) return null;

    final same = widget.existingItems
        .where((e) => e.name.trim() == name)
        .toList();
    if (same.isEmpty) return null;

    // 등록하면 자동으로 합쳐지는 경우 (서비스의 합치기 기준과 동일)
    final exact = same
        .where(
          (e) =>
              e.category == d.category &&
              e.unit == d.unit &&
              e.storage == d.storage &&
              _sameDay(e.expirationDate, d.expirationDate),
        )
        .firstOrNull;

    final String text;
    if (exact != null) {
      text =
          '소비기한이 같은 ${_dDay(exact.expirationDate)} $name ${exact.quantity}${exact.unit}와 합쳐져요';
    } else {
      final shown = same
          .take(3)
          .map((e) => '${_dDay(e.expirationDate)} ${e.quantity}${e.unit}')
          .join(', ');
      final more = same.length > 3 ? ' 외 ${same.length - 3}건' : '';
      text = '냉장고에 $name ${same.length}건 있어요 · $shown$more';
    }

    return Padding(
      padding: const EdgeInsets.only(left: 12, top: 2),
      child: Row(
        children: [
          Icon(Icons.kitchen, size: 14, color: Colors.indigo.shade400),
          const SizedBox(width: 4),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: 12, color: Colors.indigo.shade700),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dropdown(
    String value,
    List<String> options,
    bool enabled,
    void Function(String) onChanged,
  ) {
    return DropdownButton<String>(
      value: value,
      isDense: true,
      items: options
          .map((o) => DropdownMenuItem(value: o, child: Text(o)))
          .toList(),
      onChanged: enabled
          ? (v) {
              if (v != null) setState(() => onChanged(v));
            }
          : null,
    );
  }

  void _openViewer(int index) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            _PhotoViewer(photos: widget.photos, initialIndex: index),
      ),
    );
  }

  Widget _buildPhotoStrip() {
    return SizedBox(
      height: 72,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        itemCount: widget.photos.length,
        separatorBuilder: (_, _) => const SizedBox(width: 8),
        itemBuilder: (_, i) => GestureDetector(
          onTap: () => _openViewer(i),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.file(
              File(widget.photos[i].path),
              width: 72,
              height: 72,
              fit: BoxFit.cover,
              cacheWidth: 200,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDraftCard(_Draft d) {
    final enabled = d.selected;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      surfaceTintColor: Colors.transparent, // 테마 색이 섞이지 않게
      child: Opacity(
        opacity: enabled ? 1 : 0.45, // 체크 해제하면 흐리게
        child: Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, 12, 4),
          child: Column(
            children: [
              Row(
                children: [
                  Checkbox(
                    value: d.selected,
                    onChanged: (v) => setState(() => d.selected = v ?? false),
                  ),
                  Expanded(
                    child: TextField(
                      controller: d.name,
                      enabled: enabled,
                      onChanged: (_) => setState(() => _reestimate(d)),
                      decoration: const InputDecoration(
                        hintText: '재료 이름',
                        isDense: true,
                      ),
                    ),
                  ),
                ],
              ),
              ?_buildExistingHint(d),
              Padding(
                padding: const EdgeInsets.only(left: 12, top: 4),
                child: Row(
                  children: [
                    SizedBox(
                      width: 64,
                      child: TextField(
                        controller: d.quantity,
                        enabled: enabled,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: '수량',
                          isDense: true,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    _dropdown(d.unit, _units, enabled, (v) => d.unit = v),
                    const Spacer(),
                    _dropdown(d.category, _categories, enabled, (v) {
                      d.category = v;
                      _reestimate(d);
                    }),
                    const SizedBox(width: 12),
                    _dropdown(d.storage, _storages, enabled, (v) {
                      d.storage = v;
                      _reestimate(d);
                    }),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 0, 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text(
                          '소비기한',
                          style: TextStyle(color: Colors.grey, fontSize: 13),
                        ),
                        _dateTag(d),
                      ],
                    ),
                    const SizedBox(height: 4),
                    // 체크 해제한 카드는 다른 칸처럼 흐리게 + 못 누르게
                    IgnorePointer(
                      ignoring: !enabled,
                      child: Opacity(
                        opacity: enabled ? 1 : 0.5,
                        child: ExpirationDateField(
                          value: d.expirationDate,
                          showLabel: false,
                          onChanged: (v) => setState(() {
                            d.expirationDate = v;
                            d.dateFromPhoto = false;
                            d.dateEdited = true;
                          }),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 소비기한 옆 작은 표시: 이미 지남 / 사진에서 읽음 / 자동 계산
  Widget _dateTag(_Draft d) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    String? text;
    Color color = Colors.grey;
    if (d.expirationDate.isBefore(today)) {
      text = '이미 지난 날짜';
      color = Colors.red;
    } else if (d.dateFromPhoto) {
      text = '사진에서 읽음';
      color = Colors.indigo;
    } else if (!d.dateEdited) {
      text = '자동 계산';
      color = Colors.indigo.shade300;
    }
    if (text == null) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(left: 6),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          color: color,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.result.sourceType == 'receipt'
        ? '영수증에서 찾은 재료'
        : '사진에서 찾은 재료';

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          TextButton(
            onPressed: _drafts.isEmpty ? null : _toggleAll,
            child: Text(_allSelected ? '전체 해제' : '전체 선택'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
        children: [
          if (widget.photos.isNotEmpty) ...[
            _buildPhotoStrip(),
            const SizedBox(height: 8),
          ],
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 0, 4, 8),
            child: Text(
              '재료 ${widget.result.items.length}개를 찾았어요. 등록 전에 확인하고 고쳐주세요.',
              style: const TextStyle(color: Colors.grey, fontSize: 13),
            ),
          ),
          ..._drafts.map(_buildDraftCard),
          const SizedBox(height: 4),
          TextButton.icon(
            onPressed: _addEmpty,
            icon: const Icon(Icons.add),
            label: const Text('재료 직접 입력'),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: SizedBox(
            height: 48,
            child: ElevatedButton(
              onPressed: _selectedCount == 0 ? null : _submit,
              child: Text('$_selectedCount개 등록'),
            ),
          ),
        ),
      ),
    );
  }
}

/// 사진 크게 보기: 두 손가락 확대, 옆으로 넘기기
class _PhotoViewer extends StatefulWidget {
  final List<XFile> photos;
  final int initialIndex;

  const _PhotoViewer({required this.photos, required this.initialIndex});

  @override
  State<_PhotoViewer> createState() => _PhotoViewerState();
}

class _PhotoViewerState extends State<_PhotoViewer> {
  late final PageController _pageController = PageController(
    initialPage: widget.initialIndex,
  );
  late int _index = widget.initialIndex;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        // 앱 전체 AppBar가 투명이라 여기선 직접 지정
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: widget.photos.length > 1
            ? Text('${_index + 1} / ${widget.photos.length}')
            : null,
      ),
      body: PageView.builder(
        controller: _pageController,
        itemCount: widget.photos.length,
        onPageChanged: (i) => setState(() => _index = i),
        itemBuilder: (_, i) => InteractiveViewer(
          minScale: 1,
          maxScale: 5,
          child: Center(
            child: Image.file(File(widget.photos[i].path), fit: BoxFit.contain),
          ),
        ),
      ),
    );
  }
}
