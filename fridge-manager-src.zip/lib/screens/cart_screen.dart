import 'dart:async';
import 'package:flutter/material.dart';
import '../services/cart_service.dart';
import 'shopping_detail_screen.dart';
import 'add_ingredient_screen.dart';
import '../services/product_name_formatter.dart';
import '../services/kamis_cache_service.dart';
import '../models/recipe_mode.dart';
import '../services/api_client.dart';

typedef OnRequestRecipe = void Function(RecipeMode mode);

class CartScreen extends StatefulWidget {
  final OnRequestRecipe? onRequestRecipe;

  const CartScreen({super.key, this.onRequestRecipe});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final CartService _cartService = CartService();
  final KamisCacheService _kamisCache = KamisCacheService();
  bool _isLoading = true;
  List<Map<String, dynamic>> _cartDocs = [];
  Map<String, int> _quantities = {};
  bool _isMoveMode = false;
  final Set<String> _selectedIds = {};
  List<Map<String, dynamic>> _allItems = [];
  StreamSubscription<List<Map<String, dynamic>>>? _cartSubscription;
  StreamSubscription<Map<String, int>>? _quantitySubscription;
  String? _loadError;

  @override
  void initState() {
    super.initState();
    _cartSubscription = _cartService.watchItems().listen((docs) {
      if (!mounted) return;
      setState(() => _cartDocs = docs);
    });
    _quantitySubscription = _cartService.watchQuantities().listen((map) {
      if (!mounted) return;
      setState(() => _quantities = map);
    });
    _fetchData();
  }

  @override
  void dispose() {
    _cartSubscription?.cancel();
    _quantitySubscription?.cancel();
    super.dispose();
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _fetchData() async {
    setState(() {
      _isLoading = true;
      _loadError = null;
    });

    try {
      final items = await _kamisCache.getDailyItems();
      if (!mounted) return;
      setState(() {
        _allItems = items;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('KAMIS API 오류: $e');
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _loadError = friendlyError(e, fallback: '가격 정보를 불러오지 못했어요');
      });
    }
  }

  int _quantityOf(Map<String, dynamic> item) {
    final productNo = item['productno']?.toString() ?? '';
    final productName = item['productName']?.toString() ?? '';
    final key = _cartService.keyFor(productNo, productName);
    return _quantities[key] ?? 1;
  }

  String _formatNumber(int value) {
    return value.toString().replaceAllMapped(
      RegExp(r'(\d)(?=(\d{3})+(?!\d))'),
      (m) => '${m[1]},',
    );
  }

  /// 가격 정보가 없는 품목은 저장해둔 이름을, 있으면 KAMIS 이름 포맷을 사용
  String _nameOf(Map<String, dynamic> item) =>
      (item['_displayName'] as String?) ?? ProductNameFormatter.format(item);

  Future<void> _incrementItem(Map<String, dynamic> item) async {
    final productNo = item['productno']?.toString() ?? '';
    final productName = item['productName']?.toString() ?? '';
    final displayName = _nameOf(item);
    if (productNo.isEmpty) return;
    await _cartService.add(
      productNo: productNo,
      productName: productName,
      displayName: displayName,
    );
  }

  Future<void> _decrementItem(Map<String, dynamic> item) async {
    final productNo = item['productno']?.toString() ?? '';
    final productName = item['productName']?.toString() ?? '';
    if (productNo.isEmpty) return;
    await _cartService.decrement(
      productNo: productNo,
      productName: productName,
    );
  }

  Future<void> _removeFromCart(Map<String, dynamic> item) async {
    final productNo = item['productno']?.toString() ?? '';
    final productName = item['productName']?.toString() ?? '';
    if (productNo.isEmpty) return;

    final displayName = _nameOf(item);

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('제거 확인'),
        content: Text('$displayName을(를) 담아놓기에서 제거할까요?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('취소'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('제거', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm != true || !mounted) return;

    await _cartService.remove(productNo, productName);
    _showSnack('$displayName 담아놓기에서 제거됨');
  }

  Future<void> _moveSelectedToFridge() async {
    if (_selectedIds.isEmpty) return;

    // 선택된 항목들 차례로 AddIngredientScreen 띄우기
    final selectedItems = _cartItems.where((item) {
      final productNo = item['productno']?.toString() ?? '';
      final productName = item['productName']?.toString() ?? '';
      final key = _cartService.keyFor(productNo, productName);
      return _selectedIds.contains(key);
    }).toList();

    for (final item in selectedItems) {
      if (!mounted) return;

      final productNo = item['productno']?.toString() ?? '';
      final productName = item['productName']?.toString() ?? '';
      final cleanName = ProductNameFormatter.toSearchKeyword(_nameOf(item));

      final savedName = await Navigator.push<String>(
        context,
        MaterialPageRoute(
          builder: (_) => AddIngredientScreen(prefilledName: cleanName),
        ),
      );

      if (savedName != null && savedName.isNotEmpty && mounted) {
        await _cartService.remove(productNo, productName);
      }
    }

    if (!mounted) return;
    setState(() {
      _selectedIds.clear();
      _isMoveMode = false;
    });
  }

  void _goToRecipeRecommendation() {
    if (_cartItems.isEmpty) {
      _showSnack('담아놓기가 비어있어요');
      return;
    }

    Navigator.pop(context);
    widget.onRequestRecipe?.call(RecipeMode.shopping);
  }

  List<Map<String, dynamic>> get _cartItems {
    // 오늘 KAMIS 목록을 키로 찾기 쉽게
    final priced = <String, Map<String, dynamic>>{};
    for (final item in _allItems) {
      final key = _cartService.keyFor(
        item['productno']?.toString() ?? '',
        item['productName']?.toString() ?? '',
      );
      priced[key] = item;
    }

    // 기준은 Firestore에 담긴 품목 전부
    return _cartDocs.map((doc) {
      final found = priced[doc['_key']];
      if (found != null) return found;

      // 오늘 가격 목록에 없는 품목 → 저장된 정보로 표시 (가격 없음)
      return <String, dynamic>{
        'productno': doc['productno']?.toString() ?? '',
        'productName': doc['productName']?.toString() ?? '',
        '_displayName':
            doc['displayName']?.toString() ??
            doc['productName']?.toString() ??
            '',
        '_noPrice': true,
      };
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final cartItems = _cartItems;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          _isMoveMode
              ? '${_selectedIds.length}개 선택됨'
              : '담아놓기 (${cartItems.length})',
        ),
        actions: _isMoveMode
            ? [
                TextButton(
                  onPressed: () {
                    setState(() {
                      _selectedIds.clear();
                      _isMoveMode = false;
                    });
                  },
                  child: const Text('취소', style: TextStyle(color: Colors.red)),
                ),
                TextButton(
                  onPressed: _selectedIds.isEmpty
                      ? null
                      : _moveSelectedToFridge,
                  child: const Text('이동'),
                ),
              ]
            : [
                IconButton(
                  icon: const Icon(Icons.kitchen),
                  tooltip: '냉장고로 이동',
                  onPressed: cartItems.isEmpty
                      ? null
                      : () => setState(() => _isMoveMode = true),
                ),
                IconButton(
                  icon: const Icon(Icons.restaurant_menu),
                  tooltip: '이 담아놓기로 레시피 추천',
                  onPressed: cartItems.isEmpty
                      ? null
                      : _goToRecipeRecommendation,
                ),
              ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : cartItems.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Text(
                  _loadError ?? '담아놓기 화면이 비어있어요\n\n마음에 드는 식재료를 담아보세요',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.grey, height: 1.5),
                ),
              ),
            )
          : Column(
              children: [
                // 가격을 못 받아온 경우: 목록은 보여주되 이유를 위에 표시
                if (_loadError != null)
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.orange.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      _loadError!.replaceAll('\n\n', ' '),
                      style: const TextStyle(fontSize: 13),
                    ),
                  ),
                Expanded(
                  child: ListView.builder(
                    itemCount: cartItems.length,
                    itemBuilder: (context, index) {
                      final item = cartItems[index];
                      return _buildCartItem(item);
                    },
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildCartItem(Map<String, dynamic> item) {
    final displayName = _nameOf(item);
    final noPrice = item['_noPrice'] == true;
    final quantity = _quantityOf(item);
    final productNo = item['productno']?.toString() ?? '';
    final productName = item['productName']?.toString() ?? '';
    final key = _cartService.keyFor(productNo, productName);

    final unitPrice =
        int.tryParse(item['dpr1']?.toString().replaceAll(',', '') ?? '') ?? 0;
    final totalPrice = unitPrice * quantity;

    final isSelected = _selectedIds.contains(key);

    // 이동 모드: Card 전체 InkWell
    if (_isMoveMode) {
      return Card(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        color: isSelected ? Colors.deepPurple.shade50 : null,
        child: InkWell(
          onTap: () {
            setState(() {
              if (isSelected) {
                _selectedIds.remove(key);
              } else {
                _selectedIds.add(key);
              }
            });
          },
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
            child: Row(
              children: [
                Icon(
                  isSelected
                      ? Icons.check_circle
                      : Icons.radio_button_unchecked,
                  color: isSelected ? Colors.deepPurple : Colors.grey,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        displayName,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        noPrice
                            ? '오늘 가격 정보 없음'
                            : '${item['dpr1']}원 / ${item['unit']}',
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  noPrice ? '-' : '${_formatNumber(totalPrice)}원',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.deepPurple,
                  ),
                ),
                const SizedBox(width: 12),
                SizedBox(
                  width: 40,
                  child: Text(
                    '$quantity개',
                    textAlign: TextAlign.right,
                    style: const TextStyle(fontSize: 18),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // 일반 모드: 기존 구조 (Stack + 부분 InkWell)
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 40, 16),
            child: Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () {
                      if (noPrice) return;
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ShoppingDetailScreen(
                            item: item,
                            displayName: displayName,
                          ),
                        ),
                      );
                    },
                    borderRadius: BorderRadius.circular(4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                displayName,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 17,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                noPrice
                                    ? '오늘 가격 정보 없음'
                                    : '${item['dpr1']}원 / ${item['unit']}',
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          noPrice ? '-' : '${_formatNumber(totalPrice)}원',
                          textAlign: TextAlign.right,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.deepPurple,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.remove_circle_outline),
                  visualDensity: VisualDensity.compact,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  onPressed: quantity <= 1 ? null : () => _decrementItem(item),
                ),
                SizedBox(
                  width: 20,
                  child: Text(
                    '$quantity',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.add_circle_outline),
                  visualDensity: VisualDensity.compact,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  onPressed: () => _incrementItem(item),
                ),
              ],
            ),
          ),
          Positioned(
            top: 0,
            right: 0,
            child: IconButton(
              icon: const Icon(Icons.close, size: 16),
              color: Colors.grey,
              visualDensity: VisualDensity.compact,
              constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
              padding: EdgeInsets.zero,
              tooltip: '제거',
              onPressed: () => _removeFromCart(item),
            ),
          ),
        ],
      ),
    );
  }
}
